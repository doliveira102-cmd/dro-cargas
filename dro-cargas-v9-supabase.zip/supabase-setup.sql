-- DRO Cargas V9 - Supabase setup
-- Rode este SQL uma vez no Supabase: SQL Editor > New query > Run

create table if not exists public.app_state (
  id text primary key,
  data jsonb not null default '{}'::jsonb,
  updated_at timestamptz not null default now()
);

alter table public.app_state enable row level security;

drop policy if exists "DRO app_state select" on public.app_state;
drop policy if exists "DRO app_state insert" on public.app_state;
drop policy if exists "DRO app_state update" on public.app_state;
drop policy if exists "DRO app_state delete" on public.app_state;

create policy "DRO app_state select"
on public.app_state for select
to anon
using (true);

create policy "DRO app_state insert"
on public.app_state for insert
to anon
with check (true);

create policy "DRO app_state update"
on public.app_state for update
to anon
using (true)
with check (true);

create policy "DRO app_state delete"
on public.app_state for delete
to anon
using (true);

insert into public.app_state (id, data)
values ('main', '{}'::jsonb)
on conflict (id) do nothing;
